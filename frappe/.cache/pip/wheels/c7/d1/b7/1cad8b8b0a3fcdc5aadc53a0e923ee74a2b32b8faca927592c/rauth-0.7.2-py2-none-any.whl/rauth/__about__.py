__title__ = 'rauth'
__version_info__ = ('0', '7', '2')
__version__ = '.'.join(__version_info__)
__author__ = 'Max Countryman'
__license__ = 'MIT'
__copyright__ = 'Copyright 2013 litl'
